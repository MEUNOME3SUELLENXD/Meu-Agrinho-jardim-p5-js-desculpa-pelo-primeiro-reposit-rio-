// Variáveis para controlar o jardim

let flores = [];

let agua = 100;

let tempo = 0;

// Função para criar uma flor

class Flor {

  constructor(x, y) {

    this.x = x;

    this.y = y;

    this.tamanho = 10;

    this.cor = color(random(255), random(255), random(255));

    this.crescimento = 0;

  }

  // Desenhar a flor, eu juro que essas bolas são flores

  display() {

    fill(this.cor);

    ellipse(this.x, this.y, this.tamanho);

  }

  // Crescer a flor

  crescer() {

    if (this.crescimento < 100) {

      this.crescimento += 1;

      this.tamanho += 1.5;

    }

  }

  // Regar a flor

  regar() {

    if (agua > 0) {

      agua -= 10;

      this.crescer();

    }

  }

}

function setup() {

  createCanvas(800, 600);

  background(255);

  // Criar 10 flores no jardim

  for (let i = 0; i < 10; i++) {

    flores.push(new Flor(random(width), random(height)));

  }

}

function draw() {

  background(0, 128, 0);

  // Desenhar o jardim

  for (let i = 0; i < flores.length; i++) {

    flores[i].display();

  }

  // Mostrar o nível de água

  fill(0);

  textSize(24);

  text(`Água: ${agua}`, 10, 30);

  // Mostrar o tempo

  tempo++;

  text(`Tempo: ${tempo}`, 10, 60);

  // Crescer as flores com o tempo

  if (tempo % 100 == 0) {

    for (let i = 0; i < flores.length; i++) {

      flores[i].crescer();

    }

  }

  // Adicionar nova flor ao jardim

  if (mouseIsPressed && mouseButton == RIGHT) {

    flores.push(new Flor(mouseX, mouseY));

  }

}

// Regar as flores ao clicar

function mousePressed() {

  if (mouseButton == LEFT) {

    for (let i = 0; i < flores.length; i++) {

      if (dist(mouseX, mouseY, flores[i].x, flores[i].y) < flores[i].tamanho / 2) {

        flores[i].regar();

      }

    }

  }

}